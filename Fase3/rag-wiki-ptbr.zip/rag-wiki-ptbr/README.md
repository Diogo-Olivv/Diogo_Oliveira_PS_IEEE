# RAG Wikipedia PT-BR (local)

Pipeline RAG simples sobre `wikimedia/wikipedia` PT-BR.
Atividade Trainee CIS 2026 — IEEE CIS UnB.

## Stack
- **Retriever**: `sentence-transformers/all-MiniLM-L6-v2` + FAISS (cosine via IP)
- **Generator**: `google/flan-t5-base`
- **Dataset**: `wikimedia/wikipedia` config `20231101.pt` (streaming)

## Estrutura
```
.
├── ingest.py        # baixa wiki → chunks → embeddings → FAISS
├── rag.py           # classe RAGPipeline
├── main.py          # CLI interativo
├── eval.py          # RAG vs closed-book
├── data/            # index + metadados (gerado por ingest.py)
└── requirements.txt
```

## Setup

```bash
python -m venv .venv
source .venv/bin/activate          # win: .venv\Scripts\activate
pip install -r requirements.txt
```

## Uso

```bash
# 1. construir index (1x) — comece pequeno
python ingest.py --n_articles 500

# 2. CLI interativo
python main.py

# 3. comparação RAG vs closed-book
python eval.py
```

### Comandos dentro do CLI
| comando   | efeito                       |
|-----------|------------------------------|
| `:cb`     | toggle closed-book           |
| `:k 6`    | muda top-k                   |
| `:q`      | sair                         |

## Análise opcional (atividade b): impacto do chunk size

```bash
python ingest.py --chunk_size 256 --overlap 32
mv data data_256
python ingest.py --chunk_size 512 --overlap 64
mv data data_512
# rode eval em cada um e compare
```

Heurísticas:
- **256** → trechos precisos, podem cortar contexto necessário.
- **512** → mais contexto, top-1 menos preciso.
- **overlap ≈ 10-15%** do chunk_size é bom default.

## Notas técnicas
- `normalize_embeddings=True` + `IndexFlatIP` ⇒ inner product = cosine sim.
- `IndexFlatIP` é O(N) — OK até ~1M chunks; acima disso usar `IndexIVFFlat`/HNSW.
- `flan-t5-base` é fraco em PT puro. Upgrade: `unicamp-dl/ptt5-base-portuguese-vocab` ou Llama-3 quantizado.

## Tempo aproximado (CPU)
| n_articles | chunks ≈ | ingest | RAM   |
|-----------:|---------:|-------:|------:|
| 500        | 4k       | 3 min  | 1 GB  |
| 2000       | 16k      | 12 min | 2 GB  |
| 5000       | 40k      | 30 min | 4 GB  |
