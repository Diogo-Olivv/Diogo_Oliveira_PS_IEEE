"""
app.py
FastAPI servindo RAGPipeline.

Rotas:
    GET  /health
    POST /ask      → {question, k?, closed_book?}
    POST /retrieve → só retrieval (debug)
"""
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from app.rag import RAGPipeline

pipeline: Optional[RAGPipeline] = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global pipeline
    print("Carregando RAGPipeline ...")
    pipeline = RAGPipeline()
    print("OK")
    yield
    pipeline = None


api = FastAPI(title="RAG Wikipedia PT-BR", version="1.0", lifespan=lifespan)


class AskBody(BaseModel):
    question: str = Field(..., min_length=3)
    k: int = Field(4, ge=1, le=10)
    closed_book: bool = False


@api.get("/health")
def health():
    return {"status": "ok", "ready": pipeline is not None}


@api.post("/ask")
def ask(body: AskBody):
    if pipeline is None:
        raise HTTPException(503, "pipeline ainda carregando")
    return pipeline.ask(body.question, k=body.k, closed_book=body.closed_book)


@api.post("/retrieve")
def retrieve(body: AskBody):
    if pipeline is None:
        raise HTTPException(503, "pipeline ainda carregando")
    return {"hits": pipeline.retrieve(body.question, k=body.k)}


# rodar local: uvicorn app.app:api --host 0.0.0.0 --port 8000
