"""
eval.py
Comparação qualitativa: RAG vs closed-book.
Imprime respostas lado a lado para perguntas-teste.
"""
from app.rag import RAGPipeline

QUESTIONS = [
    "Quem foi Dom Pedro II?",
    "O que é o teorema de Pitágoras?",
    "Qual a capital do estado do Amazonas?",
    "Quando foi proclamada a República no Brasil?",
    "O que é fotossíntese?",
]


def main():
    rag = RAGPipeline()
    for q in QUESTIONS:
        print("=" * 80)
        print(f"Q: {q}")
        cb = rag.ask(q, closed_book=True)
        rg = rag.ask(q, closed_book=False)
        print(f"\n[closed-book] {cb['answer']}")
        print(f"\n[RAG]         {rg['answer']}")
        print(f"\nfontes: {[s['title'] for s in rg['sources']]}")
    print("=" * 80)


if __name__ == "__main__":
    main()
